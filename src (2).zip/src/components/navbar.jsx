import "./navbar.css";
import { useEffect, useState } from "react";

function Navbar() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    window.addEventListener("scroll", () => {
      if (window.scrollY > 100) {
        setShow(true);
      } else {
        setShow(false);
      }
    });

    return () => {
      window.removeEventListener("scroll", () => {});
    };
  }, []);

<Link to="/watchlist">
  My Watchlist
</Link>


  return (
    <div className={`nav ${show && "nav_black"}`}>
      <h2 className="logo">Movie Trailers</h2>
      <img
        className="avatar"
        src="https://www.shutterstock.com/image-vector/3d-online-cinema-portal-landing-page-2427628823?trackingId=9c196b86-89ed-4f86-bbcf-bb130c6f6bc8&listId=searchResults"
        alt="avatar"
      />
    </div>
  );
}

export default Navbar;
